/*  
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bergerproject3;

/**
 *
 * @author khari
 */
public class BergerProject3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Deck d = new Deck();
       Discard dp = new Discard();
       Player p = new Player();
       Computer c = new Computer();
       Game game = new Game(d, p, c, dp);
       game.start();
        
         
         
    }
    
}
