/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bergerproject3;

import java.util.ArrayList;

/**
 *
 * @author khari
 */
public class Player {

    private ArrayList<Card> hand = new ArrayList<>();
    private boolean turn = true;

    public Player() {
        this.hand = hand;
    }

    public ArrayList<Card> getHand() {
        return hand;
    }

    public void draw(Card c) {
        hand.add(c);
    }

    public Card getCard(int index) {
        return hand.get(index);
    }
 
    public void DisDraw(Deck d, Discard pile) {
        System.out.println("You will pick up the " + pile.peek());
        hand.add(pile.pop());
    }
    
    public void deckDraw(Deck d, Discard pile) {
        System.out.println("You drew the " + d.peek());
        hand.add(d.pDraw(pile));
    }

    /* public boolean isTurn() {
        return turn;
    }

    public void setTurn(boolean turn) {
        this.turn = turn;
    }*/
    public void discard(int index, Discard pile) {
        System.out.println("You will discard the " + getCard(index - 1));
        pile.add(hand.remove(index - 1));
        //turn = false;
    }

    //you use this one after you draw
    public void showHandD() {
        System.out.println("Now your cards are:");
        int count = 0;
        for (Card card : hand) {
            count += 1;
            System.out.println(count + ". " + card);
        }
    }

    public void showHand() {
        System.out.println("Your cards are:");
        int count = 0;
        for (Card card : hand) {
            count += 1;
            System.out.println(count + ". " + card);
        }
    }
    
    

}
