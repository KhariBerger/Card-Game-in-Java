/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bergerproject3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author khari
 */
public class Deck {

    private Queue<Card> deck = new LinkedList<>();
    private final String[] suit = {"Hearts", "Clubs", "Diamonds", "Spades"};
    private final String[] rank = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};

    public Deck() {
        for (String s : suit) {
            for (String r : rank) {
                deck.offer(new Card(r, s));
            }
        }
    }

    public Queue<Card> getDeck() {
        return deck;
    }

    public void setDeck(Queue<Card> deck) {
        this.deck = deck;
    }

    public void shuffle() {
        ArrayList<Card> a = new ArrayList<>(deck);
        Collections.shuffle(a);
        deck.clear();
        for (Card card : a) {
            deck.offer(card);
        }
    }

    public void reshuffle(Discard d) {
        while (d.pop() != null) {
            deck.add(d.pop());
        }
    }
    
    public Card peek() {
        return deck.peek();
    }

    public Card pDraw(Discard d) {
        if (deck.peek() == null) {
            reshuffle(d);
        }
        return deck.poll();
    }

    public Card poll() {        
        return deck.poll();
    }
}
