/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bergerproject3;

/**
 *
 * @author khari
 */
public class Computer extends Player {

    private boolean turn;
    private Card keep1 = new Card("", "");
    private Card keep2 = new Card("", "");

    public Computer() {
        super();
    }

    public String Win() {
        return "I Win!";
    }

    public String Lose() {
        return "You Win";
    }

    @Override
    public void deckDraw(Deck d, Discard pile) {
        System.out.println("I drew the " + d.peek());
        super.getHand().add(d.pDraw(pile));
    }

    @Override
    public void discard(int index, Discard pile) {
        System.out.println("I will discard the " + super.getHand().get(index - 1));
        pile.add(super.getHand().remove(index - 1));
        //turn = false;
    }

    public void handSort() {
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        
        for (Card c : super.getHand()) {
            if(super.getHand().get(0).getRank().equals(c.getRank())){
                count1 += 1;
            }if(super.getHand().get(1).getRank().equals(c.getRank())){
                count2 += 1;
            }if(super.getHand().get(2).getRank().equals(c.getRank())){
                count3 += 1;
            }if(super.getHand().get(3).getRank().equals(c.getRank())){
                count4 += 1;
            }
        }
        
        if(count1 > count2 && count1 > count3 && count1 > count4){
            keep1.setRank(super.getHand().get(0).getRank());
        }else if(count2 > count1 && count2 > count3 && count2 > count4){
            keep1.setRank(super.getHand().get(1).getRank());
        }else if(count3 > count1 && count3 > count2 && count3 > count4){
            keep1.setRank(super.getHand().get(2).getRank());
        }else if(count4 > count1 && count4 > count3 && count4 > count2){
            keep1.setRank(super.getHand().get(3).getRank());
        }
        
        
        if(count1 == count2 && count1 > count3 && count1 > count4){
            keep1.setRank(super.getHand().get(0).getRank());
            keep2.setRank(super.getHand().get(1).getRank());
        }else if(count1 > count2 && count1 == count3 && count1 > count4){
            keep1.setRank(super.getHand().get(0).getRank());
            keep2.setRank(super.getHand().get(2).getRank());
        }else if(count1 > count2 && count1 > count3 && count1 == count4){
            keep1.setRank(super.getHand().get(0).getRank());
            keep2.setRank(super.getHand().get(3).getRank());
        }    
        if(count1 == count2 && count1 > count3 && count1 > count4){
            keep1.setRank(super.getHand().get(0).getRank());
            keep2.setRank(super.getHand().get(1).getRank());
        }else if(count2 > count1 && count2 == count3 && count2 > count4){
            keep1.setRank(super.getHand().get(1).getRank());
            keep2.setRank(super.getHand().get(2).getRank());
        }else if(count2 > count1 && count2 > count3 && count2 == count4){
            keep1.setRank(super.getHand().get(1).getRank());
            keep2.setRank(super.getHand().get(3).getRank());
        }
        if(count3 == count1 && count1 > count2 && count1 > count4){
            keep1.setRank(super.getHand().get(0).getRank());
            keep2.setRank(super.getHand().get(2).getRank());
        }else if(count2 > count1 && count2 == count3 && count2 > count4){
            keep1.setRank(super.getHand().get(1).getRank());
            keep2.setRank(super.getHand().get(2).getRank());
        }else if(count3 > count1 && count3 > count2 && count3 == count4){
            keep1.setRank(super.getHand().get(2).getRank());
            keep2.setRank(super.getHand().get(3).getRank());
        }
        if(count1 == count4 && count1 > count3 && count1 > count2){
            keep1.setRank(super.getHand().get(0).getRank());
            keep2.setRank(super.getHand().get(3).getRank());
        }else if(count4 > count1 && count2 == count4 && count4 > count3){
            keep1.setRank(super.getHand().get(1).getRank());
            keep2.setRank(super.getHand().get(3).getRank());
        }else if(count4 > count1 && count4 > count2 && count4 == count3){
            keep1.setRank(super.getHand().get(2).getRank());
            keep2.setRank(super.getHand().get(3).getRank());
        }
    }

    public void setKeep1(Card keep1) {
        this.keep1 = keep1;
    }

    public Card getKeep1() {
        return keep1;
    }

    public Card getKeep2() {
        return keep2;
    }

    public void setKeep2(Card keep2) {
        this.keep2 = keep2;
    }

    public void drawLogic(Deck d, Discard pile) {
       if (!pile.isEmpty()) {
            if (pile.peek().getRank().equals(keep1.getRank()) || pile.peek().getRank().equals(keep2.getRank())) {
                System.out.println("I will pick up the " + pile.peek());
                super.getHand().add(pile.pop());
                handSort();
                int count = 0;
                for (Card card : super.getHand()) {
                    count += 1;
                    if (!card.getRank().equals(keep1.getRank()) || !card.getRank().equals(keep2.getRank())) {
                        discard(count, pile);
                        break;
                    }
                }
            } else {
                deckDraw(d, pile);
                handSort();
                int count = 0;
                for (Card card : super.getHand()) {
                    count += 1;
                    if (!card.getRank().equals(keep1.getRank()) || !card.getRank().equals(keep2.getRank())) {
                        discard(count, pile);
                        break;
                    }
                }
            }
        } else {
            deckDraw(d, pile);
            handSort();
            int count = 0;
            for (Card card : super.getHand()) {
                count += 1;
                if (!card.getRank().equals(keep1.getRank()) || !card.getRank().equals(keep2.getRank())) {
                    discard(count, pile);
                    break;
                }
            }
        }
       
       
    }

    @Override
    public void showHand() {
        System.out.println("My cards are: ");
        int count = 0;
        for (Card card : super.getHand()) {
            count += 1;
            System.out.println(count + ". " + card);
        }
    }
}
