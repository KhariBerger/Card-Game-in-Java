/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bergerproject3;

import java.util.Stack;

/**
 *
 * @author khari
 */
public class Discard {
    private Stack<Card> discardPile = new Stack<>();

    
    public void add(Card c){
        discardPile.add(c);
    }
    
    public void checkTop(){
        if(discardPile.isEmpty()){
            System.out.println("The discard pile is currently empty -- you must draw a card");
    }else{
            System.out.println("The top card of the discard pile is " + discardPile.peek()); 
        }           
    }
  
    public boolean isEmpty(){
    return discardPile.isEmpty();
}
    
    public Card peek(){
       return discardPile.peek();
    }
    
    public Card pop(){
        return discardPile.pop();
    }
    
    
    
}
    
    
    
    

