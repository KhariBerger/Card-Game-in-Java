/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bergerproject3;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author khari
 */
public class Game {

    private Player p;
    private Deck d;
    private ArrayList<Player> pList;
    private final Computer c;
    private final Discard dp;

    public Game(Deck d, Player p, Computer c, Discard dp) {
        this.d = d;
        this.p = p;
        this.c = c;
        this.dp = dp;
    }

    public void add() {
        pList.add(p);
    }

    public void deal() {
        d.shuffle();

        for (int i = 0; i < 4; i++) {
            p.draw(d.pDraw(dp));
        }

        for (int i = 0; i < 4; i++) {
            c.draw(d.poll());
        }

    }

    public void checkPWin() {
        if (winner() == true) {
            System.out.println(c.Lose());
            System.exit(0);
        }
    }

    public void checkCWin() {
        if (winner() == true) {
            System.out.println(c.Win());
            System.exit(0);
        }
    }

    public boolean winner() {
        return p.getCard(0).getRank().equals(p.getCard(1).getRank()) && p.getCard(0).getRank().equals(p.getCard(2).getRank()) && p.getCard(0).getRank().equals(p.getCard(3).getRank());
    }

    public void start() {
        Scanner input = new Scanner(System.in);
        int uNum;
        deal();
        while (true) {
            p.showHand();
            dp.checkTop();
            if (dp.isEmpty()) {
                p.deckDraw(d, dp);
                p.showHandD();
                while (true) {
                    System.out.print("Which do you want to discard?: ");
                    try {
                        uNum = input.nextInt();
                        break;
                    } catch (Exception e) {
                        System.out.println("Invalid Input");
                    }
                }
                p.discard(uNum, dp);
                checkPWin();
            } else {
                System.out.print("Do you want to pick up the " + dp.peek() + " (1) or draw a card (2)?: ");
                uNum = input.nextInt();
                if (uNum == 1) {
                    p.DisDraw(d, dp);
                    p.showHandD();
                    while (true) {
                        System.out.print("Which do you want to discard?: ");
                        try {
                            uNum = input.nextInt();
                            break;
                        } catch (Exception e) {
                            System.out.println("Invalid Input");
                        }
                    }
                    p.discard(uNum, dp);
                    checkPWin();
                } else {
                    p.deckDraw(d, dp);
                    p.showHandD();
                    while (true) {
                        System.out.print("Which do you want to discard?: ");
                        try {
                            uNum = input.nextInt();
                            break;
                        } catch (Exception e) {
                            System.out.println("Invalid Input");
                        }
                    }
                    p.discard(uNum, dp);
                    checkPWin();
                }
            }
            c.drawLogic(d, dp);
            checkCWin();
        }
    }

}
